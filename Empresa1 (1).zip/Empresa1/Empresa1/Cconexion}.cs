﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Empresa1

namespace Empresa1
{
    class Cconexion_
    {
        static private string CadenaConexion = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:" +
            "\\Users\\salas\\Downloads\Empresa1\\frmEmpresa.mdf;Integrated Security=True;Connect Timeout=30";
        private SqlConnection conexion = new SqlConnection
            (CadenaConexion);

            public SqlConnection  Abrirconexion ()
        {
            if (conexion.State == ConnectionState.Closed)
                conexion.Open();
            return conexion;
        }

        public SqlConnection Cerrarconexion ()
        {
            if (conexion.State == ConnectionState.Open)
                conexion.Close();
            return conexion;
        }

    }
