/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuentas;

import javax.swing.JOptionPane;


public class Cuentas {

    public static void main(String[] args) {
        List cuenta = new List();
        String menu[]={"Insertar","Mostrar","Número de cuentas del asociado","Saldo promedio","Exit"};  //opciones del menu en la lista desplegable
        String opc, numero, titular, titular2;  //opc: operacion que escoja usuario, value:valor a almacenar en la lista
        Double saldo;
         do{
         opc=(String)(JOptionPane.showInputDialog(null,  //componente
                 "Selected option",  //mensaje de la ventana
                 "Main Menu", // titulo de la ventana
                 1, //tipo de icono 0-3
                 null,
                 menu,  // opciones de la lista desplegable
                 menu[0]  // selecion de la lista
         ));
         switch(opc)
         {
             case "Insertar":
                 numero = JOptionPane.showInputDialog("Ingresar el número de la cuenta");
                 saldo = Double.parseDouble(JOptionPane.showInputDialog("Ingresar el saldo de la cuenta"));
                 titular = JOptionPane.showInputDialog("Ingresar el titular de la cuenta");                 
                 Cuenta c = new Cuenta(numero, saldo, titular);
                 cuenta.Add(c);
                 JOptionPane.showMessageDialog(null,"Valor registrado");
                 break;
                     
             case "Mostrar":
                     JOptionPane.showMessageDialog(null,"List \n" + cuenta.toString());
                 break;
                 
             case "Número de cuentas del asociado":
                 titular2 = JOptionPane.showInputDialog("Ingresar el titular de la cuenta");                 
                 JOptionPane.showMessageDialog(null,cuenta.SearchTitular(titular2));
                 break;  
                 
             case "Saldo promedio":                 
                 JOptionPane.showMessageDialog(null,cuenta.Promedio());
                 break;                   
        }
        }while(!opc.equals("Exit")); 
    }
 }
