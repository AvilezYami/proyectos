/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuentas;

/**
 *
 * @author user
 */
public class List {
    private Node first;
    
    //Métodos de la lista
    public List()
    {
        first=null;
    }
    
    //determina si la lista no tiene elementos(true) y si tiene (false)
    public boolean isEmpty()
    {
        return first==null;
    }
    
    //AddFirst-- el elemento que adicionemos queda como la cabeza de la lista
    public void AddFirst(Object data)
    {
        if(isEmpty())
            first = new Node(data);
        else
        {
            Node N = new Node(data);   //paso 1
            N.setLink(first);          //paso 2
            first=N;                   //paso 3
        }
    }
    
    @Override
    public String toString()
    {
        String mess="";
        Node aux = first;  //paso 1.
        
        while(aux!=null)  //paso 2.
        {
            mess= mess + aux.getData() + "\n"; //paso 2.1
            aux = aux.getLink();                //paso 2.2
        }
        return mess;
    }
    
    public Node Last()
    {
        Node aux = first, previuos=null;
        while(aux!=null)
        {
            previuos=aux;
            aux=aux.getLink();
        }
        return previuos;
    }
    //AddLast, la informacion la guarda siempre al final, quedando este de último.
    public void AddLast(Object data)
    {
        if(isEmpty())
            AddFirst(data);
        else
        {
            Node last = Last(); //paso 1
            Node N = new Node(data); //paso 2
            last.setLink(N);  //paso 3.            
        }
    }
    
    public Node Previuos(Object search)
    {
        Node aux = first, previuos=null;
        //busco por el atributo que lo identifica de forma unica
        while(aux!=null && !((Cuenta)aux.getData()).getNumero().equals(((Cuenta)(search)).getNumero()))
        {            
            previuos = aux;
            aux=aux.getLink();
        }
        if (aux!=null)
            return previuos;
        else
            return null;
    }
    
    public int size()
    {
        Node aux = first;
        int counter = 0;
        while(aux!=null)
        {
            counter++;
            aux = aux.getLink();
        }
        return counter;
    }
    
    public void Add(Cuenta data)
    {
        if(isEmpty())
            AddFirst(data);
        else
        {
            //Recorremos la lista
            Node aux = first;
            while(aux!=null)
                aux=aux.getLink();
            
            //preguntamos en que parte queda el auxiliar -  inicio, final o en una posición intermedia
            if(aux==null)  //final
                AddLast(data);
            else
            {
                Node previuos = Previuos(aux.getData());
                if(previuos==null)  //inicio
                    AddFirst(data);  
                else  //posición intermedia
                {
                    Node n=new Node(data);
                    n.setLink(aux);
                    previuos.setLink(n);
                }
            }
        }
    }
    
    public String SearchTitular(String Titular)
    {
        List listofTitular = new List();
        Node aux = first;
        String Result = "";
        int Contador = 0;
        double Total = 0.00;
        while(aux!=null)
        {
            if(((Cuenta)aux.getData()).getTitular().equals(Titular))
            {
                 Contador++;
                 Total = Total + ((Cuenta)aux.getData()).getSaldo();
                 //                listofTitular.AddLast(aux.getData());
            }            
            aux = aux.getLink();
        }
        Result = " Número de cuentas: " + Contador + " Total: " + Total;
        return Result;
    }    
    
    public String Promedio()
    {
        List listofTitular = new List();
        Node aux = first;
        String Result = "";
        int Contador = 0;
        double Total = 0.00, promedio = 0.00;
        while(aux!=null)
        {
            Contador++;
            Total = Total + ((Cuenta)aux.getData()).getSaldo();        
            aux = aux.getLink();
        }
        promedio = Total / Contador;
        Result = " Saldo promedio: " + promedio;
        return Result;
    }  
}
